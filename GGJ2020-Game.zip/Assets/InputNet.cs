﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class InputNet
{
    public static bool Player1Fired = false;
    public static bool Player2Fired = false;
}
